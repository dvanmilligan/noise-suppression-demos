[![npm version](https://badge.fury.io/js/genesys-cloud-webrtc-sdk.svg)](https://badge.fury.io/js/genesys-cloud-webrtc-sdk)
[![codecov](https://codecov.io/gh/MyPureCloud/genesys-cloud-webrtc-sdk/branch/master/graph/badge.svg)](https://codecov.io/gh/MyPureCloud/genesys-cloud-webrtc-sdk)
[![Test Matrix](https://github.com/MyPureCloud/genesys-cloud-webrtc-sdk/actions/workflows/matrix.yml/badge.svg?branch=develop)](https://github.com/MyPureCloud/genesys-cloud-webrtc-sdk/actions/workflows/matrix.yml)

# Genesys Cloud WebRTC SDK

### Overview
The Genesys Cloud WebRTC SDK is a client library for connecting to Genesys Cloud WebRTC
services. Supported WebRTC Features:

- WebRTC SoftPhone (Authenticated Business User/Agent Telephony - inbound/outbound, etc)
- WebRTC Video (Authenticated Business User)
- WebRTC Screen Recording (server initiated)

Demo: https://sdk-cdn.mypurecloud.com/webrtc-sdk/demo/webpack/
- Demo requires Genesys Cloud Credentials for video. Organization id and security key are required for unauthenticated screen share.

### Demo Applications

This repository includes three demo applications showcasing different audio processing approaches:

#### 1. Baseline Demo (`react-demo-app`)
Standard WebRTC SDK implementation with browser-native audio processing.
- ✅ Basic call functionality
- ✅ Device selection
- ✅ Browser noise suppression

#### 2. RNNoise Demo (`react-demo-rnnoise`)
Real-time noise suppression using RNNoise WASM in the browser.
- ✅ Real-time processing
- ✅ Adjustable parameters
- ✅ Call recording & comparison
- ⚠️ Limited effectiveness (VAD issues)

#### 3. Speex Demo (`react-demo-clearervoice`)
Open-source noise suppression using Speex DSP library.
- ✅ Real-time processing (~0ms latency)
- ✅ Open-source (BSD license)
- ✅ No backend required
- ✅ Better than RNNoise

**Quick Start:**
```bash
./switch-demo.sh  # Interactive demo switcher
```

See [DEMO-COMPARISON-SPEEX.md](./DEMO-COMPARISON-SPEEX.md) for detailed comparison and [SWITCHING-DEMOS.md](./SWITCHING-DEMOS.md) for setup instructions.

Not yet supported:
- WebRTC Video (Unauthenticated User/Guest)
- WebRTC Click-to-Call (Unauthenticated user SoftPhone, Telephony)

### Installation

``` sh
# npm
npm install --save genesys-cloud-webrtc-sdk
# yarn
yarn add genesys-cloud-webrtc-sdk
```

See [documentation][4] for usage and implementation details.

### Documentation

Documentation is available in the [documentation][4] of this repository and on the Genesys Cloud Developer Center
at [DeveloperCenter][1].

> Note: due to the constant development on the SDK, it is recommended to always reference the documentation in this repository as that will always be the most up-to-date information regarding the SDK. There can be delays in the updating of documentation on the Developer Center.

### Contributing

This repo uses [typescript semistandard][2] for code style and [Jest][3] for tests and code coverage.

To get started in development:
```sh
npm install
npm run test:watch
```

Test will rebuild as source or tests change. All linting and tests must
pass 100%, and coverage should remain at 100%.

### Testing
Run the tests using `npm test` in the command line

[1]: https://developer.mypurecloud.com/api/webrtcsdk/
[2]: https://github.com/bukalapak/tslint-config-semistandard
[3]: https://jestjs.io/en/
[4]: /doc/index.md
