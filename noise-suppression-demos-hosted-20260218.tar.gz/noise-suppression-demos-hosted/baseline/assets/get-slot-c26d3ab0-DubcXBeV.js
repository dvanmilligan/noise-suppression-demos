function t(o,r){return o==null?void 0:o.querySelector(`[slot=${r}]`)}export{t as g};
