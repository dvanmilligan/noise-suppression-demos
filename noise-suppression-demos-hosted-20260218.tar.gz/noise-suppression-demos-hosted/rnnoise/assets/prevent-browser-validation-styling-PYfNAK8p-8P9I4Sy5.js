function t(e){e.addEventListener("invalid",n=>{n.preventDefault()})}export{t as p};
