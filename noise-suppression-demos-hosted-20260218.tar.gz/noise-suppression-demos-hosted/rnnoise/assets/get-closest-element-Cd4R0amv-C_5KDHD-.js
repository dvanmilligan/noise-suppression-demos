function u(i,n=this){function s(o){if(!o||o===document||o===window)return null;o.assignedSlot&&(o=o.assignedSlot);const t=o.closest(i);return t||s(o.getRootNode().host)}return s(n)}export{u as g};
