function n(e){requestAnimationFrame(()=>requestAnimationFrame(e))}function r(e,t=100){return setTimeout(e,t)}export{r as a,n as b};
