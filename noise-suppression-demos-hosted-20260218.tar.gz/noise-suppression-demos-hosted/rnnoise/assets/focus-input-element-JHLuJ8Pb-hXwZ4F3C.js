function o(f){f&&f.focus()}export{o as f};
