function e(t){return t.charAt(0).toUpperCase()+t.slice(1)}export{e as c};
