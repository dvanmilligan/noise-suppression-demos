function r(a,o){console.error(`[${a.tagName.toLowerCase()}] ${o}`,a)}function e(a,o){console.warn(`[${a.tagName.toLowerCase()}] ${o}`,a)}export{r as a,e as l};
