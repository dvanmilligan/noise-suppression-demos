function n(e,o){var t;return(t=e.querySelector(`[slot=${o}]`))===null||t===void 0?void 0:t.textContent}export{n as g};
