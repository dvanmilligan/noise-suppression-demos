function n(e,t){switch(t){case"change":return e.dispatchEvent(new InputEvent("change",{bubbles:!0}));case"input":return e.dispatchEvent(new InputEvent("input",{bubbles:!0}))}}export{n as s};
