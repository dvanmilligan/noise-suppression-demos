function t(n,a=-1/0,i=1/0){return isNaN(n)?NaN:Math.min(Math.max(n,a),i)}export{t as c};
