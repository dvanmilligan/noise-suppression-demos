function n(e,r,s={}){const t=new MutationObserver(r);return t.observe(e,Object.assign({attributes:!0,childList:!0,subtree:!0},s)),t}export{n as o};
