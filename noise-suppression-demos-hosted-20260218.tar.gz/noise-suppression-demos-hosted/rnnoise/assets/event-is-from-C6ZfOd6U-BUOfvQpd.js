function a(r,t){const n=t.currentTarget;let e=t.target;for(;e!==n&&e!==null;){if(e.matches(r))return!0;e=e.parentElement}return!1}export{a as e};
