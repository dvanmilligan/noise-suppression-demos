function r(e){return typeof e!="string"||e.length>200?".":e.replace(/[\^$*+?.(){}[\]\\]/g,"\\$&")}export{r as s};
