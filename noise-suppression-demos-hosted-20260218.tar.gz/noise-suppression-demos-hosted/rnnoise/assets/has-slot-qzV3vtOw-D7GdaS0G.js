function t(o,e){return!!o.querySelector(`[slot=${e}]`)}export{t as h};
