function i(n,u){function s(o){if(!o||o===document||o===window)return null;o.assignedSlot&&(o=o.assignedSlot);const t=o.closest(u);return t||s(o.getRootNode().host)}return s(n)}export{i as g};
