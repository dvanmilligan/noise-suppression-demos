function r(n,o){for(const t of n.children)if(t.matches(`[slot=${o}]`))return t;return null}export{r as g};
