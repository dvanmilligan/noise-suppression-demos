function n(e){return e?"true":"false"}export{n as b};
